
 const catImage = document.getElementById("cat-image");
 console.log(catImage);


 const fetchImageButton = document.getElementById("fetch-image-button");
 console.log(fetchImageButton)


 const katycatFacts = document.getElementById("katy-cat-facts");
 console.log(katycatFacts);


 const loadMoreFactsButton = document.getElementById("load-more-facts");
 console.log(loadMoreFactsButton);

 function fetchfacts(){

   loadMoreButton.innerText = "Loading please wait..";


   fetch("https://cat-fact.herokuapp.com/facts/random?amount=3")
    .then((res) => res.json())
    .then((data) => {

      console.log(data);


       data.forEach((fact) => {
         katycatFacts.innerHTML += <div  class="fact-block"> <p>${fact.text}</p> </div> ;
      });


      loadMoreButton.innerText = "Load More";
    });
 };
 function fetchimage(){
  // set `Loading...` text while fetching the cat image
  fetchImageButton.innerText = "Loading...";

  // fetch cat image
  fetch("https://cataas.com/cat?json=true")
    .then((res) => res.json())
    .then((data) => {
      // console.log(data) and visualize it in browser to extract useful information for us
      console.log(data);

      // set innerHTML of cat-container div to the image
      catImage.innerHTML = `<img id="cat-image" src="https://cataas.com/${data.url}">`;

      // replace `Loading...` text with `Fetch New Image` after fetching the image
      fetchImageButton.innerText = "Fetch New Image";
    });
};
 

 fetchfacts();
 fetchimage();
