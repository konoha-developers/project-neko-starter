# Project Neko Starter Template

<div align="center">
  
|<img src="https://user-images.githubusercontent.com/74975876/145233466-031aee46-04be-4b1d-a229-80752a58bd21.png" width="300" height="300" />|
|---|
  
</div>

#### [project snippets/articles](https://github.com/konoha-developers/project-snippets/blob/main/projects/01-project-neko/README.md)

### Getting Started

1) Fork this repository 
2) Make a new branch with your name
3) Start working in your branch. 
